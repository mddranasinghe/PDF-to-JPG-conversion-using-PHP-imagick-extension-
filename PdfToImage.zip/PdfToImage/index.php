<?php
if (!empty($_POST['upload']) && isset($_FILES['file'])) {
    if (!empty($_FILES['file']['name'][0])) {
        
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        foreach ($_FILES['file']['name'] as $key => $filename) {
            $tempPath = $_FILES['file']['tmp_name'][$key];

            // Only process PDFs
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            if ($ext !== 'pdf') {
                echo "Skipping {$filename} (not a PDF).<br>";
                continue;
            }

            try {
                $imagick = new Imagick();
                $imagick->setResolution(100, 100);
                $imagick->readImage($tempPath);
                $imagick->setImageFormat('jpg');

                $i = 0;
                foreach ($imagick as $page) {
                    $page->setImageFormat('jpg');
                    $imagePath = $uploadDir . pathinfo($filename, PATHINFO_FILENAME) . "_page_{$i}.jpg";
                    if ($page->writeImage($imagePath)) {
                        echo "Saved image: {$imagePath}<br>";
                    } else {
                        echo "Error saving image for page {$i} of {$filename}.<br>";
                    }
                    $i++;
                }

                $imagick->clear();
                $imagick->destroy();
            } catch (Exception $e) {
                echo "Error processing {$filename}: " . $e->getMessage() . "<br>";
            }
        }
    } else {
        echo "No files selected for upload.";
    }
    exit;
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>

        </title>

    </head>
<body>
<form>
<input type=file name="file" id="file" multiple>
<input type=button value="Upload" onclick="uploadFile()">
</form>

  <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script>
function uploadFile(){

    const files = $('#file')[0].files;

    	if (files.length === 0) {
            alert('Please select at least one file.');
            return;
        }

        const fd = new FormData();
        for (let i = 0; i < files.length; i++) {
            fd.append('file[]', files[i]);
        }
   //    console.log("wwwwwwwwwwwwww", fd);
        fd.append('upload', 'true');
        $.ajax({
            url: 'index.php',
            type: 'POST',
            data: fd,
            processData: false,
            contentType: false,
             success: function(response){
               alert(response);
            },
      
           
            error: function() {
                alert('Error uploading files.');
            }
        });
    }





</script>

</body>
</html>
